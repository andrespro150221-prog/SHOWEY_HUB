export const SCRIPT_KEY = "chingatumadresho1516";
export const DISCORD_LINK = "https://discord.gg/showey";

export const LUA_SCRIPT = String.raw`-- [[ Showey Hub v3.1 FULL | Stable + Complete | Delta iOS ]]
-- TODO incluido + Anti-Crash + Fly corregido para móvil

local R = loadstring(game:HttpGet('https://sirius.menu/rayfield'))()

local W = R:CreateWindow({
    Name = "⚡ SHOWEY HUB v3.1 ⚡",
    LoadingTitle = "⚡ SHOWEY HUB ⚡",
    LoadingSubtitle = "🔄 Inicializando sistema...",
    Theme = "Ocean",
    KeySystem = true,
    KeySettings = {
        Title = "🔐 SHOWEY HUB — Verificación de Acceso",
        Subtitle = "🛡️ Sistema de Seguridad Activado",
        Note = "📱 Optimizado para iOS | Ingresa tu clave privada para continuar",
        FileName = "ShoweyV31Key",
        SaveKey = true,
        GrabKeyFromSite = false,
        Key = {"chingatumadresho1516"},
        KeyLink = "https://discord.gg/showey"
    }
})

-- ═══════════════════════════════════════════════════════════
-- SERVICIOS
-- ═══════════════════════════════════════════════════════════
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local CoreGui = game:GetService("CoreGui")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Lighting = game:GetService("Lighting")
local SoundService = game:GetService("SoundService")

local LP = Players.LocalPlayer
local Camera = Workspace.CurrentCamera

local connections = {}
local function safe(name, conn)
    if connections[name] then pcall(function() connections[name]:Disconnect() end) end
    connections[name] = conn
end
local function stop(name)
    if connections[name] then pcall(function() connections[name]:Disconnect() end) connections[name] = nil end
end

local function getChar()
    local c = LP.Character
    if not c then return nil, nil, nil end
    return c, c:FindFirstChild("HumanoidRootPart"), c:FindFirstChildOfClass("Humanoid")
end

-- ═══════════════════════════════════════════════════════════
-- ANTI-DETECCIÓN (silencioso)
-- ═══════════════════════════════════════════════════════════
pcall(function()
    if hookmetamethod then
        local oldNamecall
        oldNamecall = hookmetamethod(game, "__namecall", function(self, ...)
            local method = getnamecallmethod()
            if method == "FireServer" or method == "InvokeServer" then
                local n = tostring(self):lower()
                if n:find("detect") or n:find("anticheat") or n:find("exploit") or
                   n:find("kick") or n:find("ban") or n:find("report") or
                   n:find("violation") or n:find("security") or n:find("flag") then
                    return nil
                end
            end
            return oldNamecall(self, ...)
        end)
    end
end)

pcall(function()
    for _, v in ipairs(LP.PlayerScripts:GetDescendants()) do
        local n = v.Name:lower()
        if (n:find("anti") or n:find("cheat") or n:find("detect")) and v:IsA("LocalScript") then
            v.Disabled = true
        end
    end
end)

-- ═══════════════════════════════════════════════════════════
-- TAB 1: JUGADORES
-- ═══════════════════════════════════════════════════════════
local PlayerTab = W:CreateTab("👥 JUGADORES", 4483362458)

PlayerTab:CreateSection("🎯 Selección de Objetivo")

local targetPlayer = ""

local function getPlayerList()
    local names = {}
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= LP then table.insert(names, p.Name) end
    end
    return names
end

local PlayerDropdown = PlayerTab:CreateDropdown({
    Name = "🎯 Seleccionar Jugador Objetivo",
    Options = getPlayerList(),
    CurrentOption = {""},
    MultipleOptions = false,
    Flag = "TargetPlayer",
    Callback = function(O)
        if O and O[1] and O[1] ~= "" then
            targetPlayer = O[1]
            R:Notify({
                Title = "✅ OBJETIVO SELECCIONADO",
                Content = "🎯 " .. targetPlayer,
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

PlayerTab:CreateSection("🌍 Teletransporte")

PlayerTab:CreateButton({
    Name = "🚀 Teleportarse al Jugador",
    Callback = function()
        if targetPlayer == "" then 
            R:Notify({
                Title = "❌ ERROR",
                Content = "⚠️ Selecciona un jugador primero",
                Duration = 3,
                Image = 4483362458
            })
            return 
        end
        local p = Players:FindFirstChild(targetPlayer)
        local _, myHrp = getChar()
        if p and p.Character and p.Character:FindFirstChild("HumanoidRootPart") and myHrp then
            myHrp.CFrame = p.Character.HumanoidRootPart.CFrame * CFrame.new(0, 3, 3)
            R:Notify({
                Title = "✅ TELEPORT EXITOSO",
                Content = "📍 Llegaste a " .. targetPlayer,
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

PlayerTab:CreateButton({
    Name = "🔄 Actualizar Lista de Jugadores",
    Callback = function()
        PlayerDropdown:Refresh(getPlayerList(), true)
        R:Notify({
            Title = "✅ LISTA ACTUALIZADA",
            Content = "👥 " .. #getPlayerList() .. " jugadores encontrados",
            Duration = 2,
            Image = 4483362458
        })
    end
})

PlayerTab:CreateButton({
    Name = "📡 TP a TODOS (Secuencial)",
    Callback = function()
        local _, myHrp = getChar()
        if not myHrp then return end
        for _, p in ipairs(Players:GetPlayers()) do
            if p ~= LP and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
                myHrp.CFrame = p.Character.HumanoidRootPart.CFrame * CFrame.new(0, 3, 3)
                task.wait(1.5)
            end
        end
    end
})

PlayerTab:CreateSection("👁️ Observación")

PlayerTab:CreateToggle({
    Name = "👁️ Observar Jugador (Spectate)",
    CurrentValue = false,
    Flag = "SpectateToggle",
    Callback = function(v)
        if v and targetPlayer ~= "" then
            local p = Players:FindFirstChild(targetPlayer)
            if p and p.Character and p.Character:FindFirstChild("Humanoid") then
                Camera.CameraSubject = p.Character.Humanoid
            end
        else
            local _, _, hum = getChar()
            if hum then Camera.CameraSubject = hum end
        end
    end
})

local followEnabled = false
PlayerTab:CreateToggle({
    Name = "🚶 Seguir Jugador Automáticamente",
    CurrentValue = false,
    Flag = "FollowToggle",
    Callback = function(v)
        followEnabled = v
        if v and targetPlayer ~= "" then
            safe("Follow", RunService.Heartbeat:Connect(function()
                if not followEnabled then return end
                local p = Players:FindFirstChild(targetPlayer)
                local _, myHrp, myHum = getChar()
                if p and p.Character and p.Character:FindFirstChild("HumanoidRootPart") and myHrp and myHum then
                    local dist = (myHrp.Position - p.Character.HumanoidRootPart.Position).Magnitude
                    if dist > 5 then myHum:MoveTo(p.Character.HumanoidRootPart.Position) end
                end
            end))
        else stop("Follow") end
    end
})

PlayerTab:CreateSection("📋 Utilidades")

PlayerTab:CreateButton({
    Name = "📋 Copiar Posición del Jugador",
    Callback = function()
        if targetPlayer == "" then return end
        local p = Players:FindFirstChild(targetPlayer)
        if p and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
            local pos = p.Character.HumanoidRootPart.Position
            pcall(function() setclipboard(string.format("%.1f, %.1f, %.1f", pos.X, pos.Y, pos.Z)) end)
            R:Notify({
                Title = "✅ POSICIÓN COPIADA",
                Content = "📋 Copiada al portapapeles",
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 2: FÍSICAS
-- ═══════════════════════════════════════════════════════════
local PhysicsTab = W:CreateTab("⚡ FÍSICAS", 4483362458)

PhysicsTab:CreateSection("🏃 Velocidad")

local walkSpeedValue = 16
local speedEnabled = false

PhysicsTab:CreateToggle({
    Name = "🏃 Súper Velocidad",
    CurrentValue = false,
    Flag = "SpeedToggle",
    Callback = function(v)
        speedEnabled = v
        if v then
            safe("Speed", RunService.RenderStepped:Connect(function()
                if not speedEnabled then return end
                local _, hrp, hum = getChar()
                if not (hum and hrp) then return end
                if hum.MoveDirection.Magnitude > 0 then
                    hum.WalkSpeed = walkSpeedValue
                    if walkSpeedValue > 60 then
                        local dir = hum.MoveDirection
                        hrp.Velocity = Vector3.new(dir.X * walkSpeedValue, hrp.Velocity.Y, dir.Z * walkSpeedValue)
                    end
                else
                    hum.WalkSpeed = 0
                    hrp.Velocity = Vector3.new(0, hrp.Velocity.Y, 0)
                end
            end))
            R:Notify({
                Title = "⚡ VELOCIDAD ACTIVADA",
                Content = "🏃 " .. walkSpeedValue .. " studs/s",
                Duration = 3,
                Image = 4483362458
            })
        else
            stop("Speed")
            local _, _, hum = getChar()
            if hum then hum.WalkSpeed = 16 end
        end
    end
})

PhysicsTab:CreateSlider({
    Name = "⚡ Velocidad de Movimiento",
    Range = {16, 500},
    Increment = 5,
    Suffix = " studs/s",
    CurrentValue = 16,
    Flag = "WalkSpeedSlider",
    Callback = function(v) walkSpeedValue = v end
})

PhysicsTab:CreateSection("🦘 Salto")

local jumpValue = 50
local jumpEnabled = false

PhysicsTab:CreateToggle({
    Name = "🦘 Súper Salto",
    CurrentValue = false,
    Flag = "JumpToggle",
    Callback = function(v)
        jumpEnabled = v
        if v then
            safe("Jump", RunService.RenderStepped:Connect(function()
                if not jumpEnabled then return end
                local _, _, hum = getChar()
                if hum then hum.UseJumpPower = true; hum.JumpPower = jumpValue end
            end))
        else
            stop("Jump")
            local _, _, hum = getChar()
            if hum then hum.JumpPower = 50 end
        end
    end
})

PhysicsTab:CreateSlider({
    Name = "📐 Potencia de Salto",
    Range = {50, 500},
    Increment = 10,
    Suffix = " poder",
    CurrentValue = 50,
    Flag = "JumpPowerSlider",
    Callback = function(v) jumpValue = v end
})

local infJumpEnabled = false
PhysicsTab:CreateToggle({
    Name = "♾️ Salto Infinito",
    CurrentValue = false,
    Flag = "InfJumpToggle",
    Callback = function(v)
        infJumpEnabled = v
        if v then
            safe("InfJump", UserInputService.JumpRequest:Connect(function()
                if not infJumpEnabled then return end
                local _, _, hum = getChar()
                if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
            end))
        else stop("InfJump") end
    end
})

PhysicsTab:CreateSection("🌍 Gravedad")

local defaultGravity = Workspace.Gravity

PhysicsTab:CreateSlider({
    Name = "🌍 Gravedad del Mundo",
    Range = {0, 500},
    Increment = 10,
    CurrentValue = 196,
    Flag = "GravitySlider",
    Callback = function(v) Workspace.Gravity = v end
})

PhysicsTab:CreateButton({
    Name = "🔄 Restaurar Gravedad",
    Callback = function()
        Workspace.Gravity = defaultGravity
        R:Notify({
            Title = "✅ GRAVEDAD RESTAURADA",
            Content = "🌍 Gravedad: " .. defaultGravity,
            Duration = 2,
            Image = 4483362458
        })
    end
})

PhysicsTab:CreateSection("🎯 Habilidades Especiales")

local noclipEnabled = false
PhysicsTab:CreateToggle({
    Name = "👻 Noclip (Atravesar Paredes)",
    CurrentValue = false,
    Flag = "NoclipToggle",
    Callback = function(v)
        noclipEnabled = v
        if v then
            safe("Noclip", RunService.Stepped:Connect(function()
                if not noclipEnabled then return end
                local char = LP.Character
                if char then
                    for _, part in ipairs(char:GetDescendants()) do
                        if part:IsA("BasePart") then part.CanCollide = false end
                    end
                end
            end))
        else stop("Noclip") end
    end
})

PhysicsTab:CreateButton({
    Name = "💨 Dash / Impulso Rápido",
    Callback = function()
        local _, hrp, hum = getChar()
        if hrp and hum then
            local dir = hum.MoveDirection
            if dir.Magnitude == 0 then dir = hrp.CFrame.LookVector end
            local bv = Instance.new("BodyVelocity")
            bv.MaxForce = Vector3.new(1e5, 0, 1e5)
            bv.Velocity = dir * 150
            bv.Parent = hrp
            task.delay(0.3, function() bv:Destroy() end)
        end
    end
})

PhysicsTab:CreateToggle({
    Name = "🌙 Moon Walk",
    CurrentValue = false,
    Flag = "MoonWalkToggle",
    Callback = function(v)
        local _, hrp = getChar()
        if v and hrp then
            local bf = Instance.new("BodyForce")
            bf.Name = "ShoweyMoon"
            bf.Force = Vector3.new(0, Workspace.Gravity * hrp:GetMass() * 0.75, 0)
            bf.Parent = hrp
        elseif hrp then
            local bf = hrp:FindFirstChild("ShoweyMoon")
            if bf then bf:Destroy() end
        end
    end
})

PhysicsTab:CreateToggle({
    Name = "🐇 Bunny Hop",
    CurrentValue = false,
    Flag = "BunnyHopToggle",
    Callback = function(v)
        if v then
            safe("BunnyHop", RunService.Heartbeat:Connect(function()
                local _, _, hum = getChar()
                if hum and hum.MoveDirection.Magnitude > 0 then
                    if hum:GetState() == Enum.HumanoidStateType.Running then hum.Jump = true end
                end
            end))
        else stop("BunnyHop") end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 3: VUELO — CORREGIDO PARA MÓVIL
-- ═══════════════════════════════════════════════════════════
local FlyTab = W:CreateTab("🚀 VOLAR", 4483362458)

FlyTab:CreateSection("✈️ Sistema de Vuelo")

local flyEnabled = false
local flySpeed = 50
local flyBV, flyBG = nil, nil
local upPressed, downPressed = false, false
local flyGui = nil

local function createFlyButtons()
    if flyGui then flyGui:Destroy() end
    flyGui = Instance.new("ScreenGui")
    flyGui.Name = "ShoweyFly_" .. math.random(10000, 99999)
    flyGui.ResetOnSpawn = false
    flyGui.Parent = CoreGui

    local container = Instance.new("Frame", flyGui)
    container.Size = UDim2.new(0, 90, 0, 200)
    container.Position = UDim2.new(1, -110, 0.3, 0)
    container.BackgroundTransparency = 1

    -- BOTÓN SUBIR (▲)
    local upBtn = Instance.new("TextButton", container)
    upBtn.Size = UDim2.new(1, 0, 0, 85)
    upBtn.Position = UDim2.new(0, 0, 0, 0)
    upBtn.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
    upBtn.BackgroundTransparency = 0.2
    upBtn.Text = "▲\nSUBIR"
    upBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    upBtn.TextSize = 20
    upBtn.Font = Enum.Font.GothamBlack
    local upCorner = Instance.new("UICorner", upBtn)
    upCorner.CornerRadius = UDim.new(0, 18)
    local us = Instance.new("UIStroke", upBtn)
    us.Color = Color3.fromRGB(100, 255, 255)
    us.Thickness = 3
    us.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    local upGrad = Instance.new("UIGradient", upBtn)
    upGrad.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 220, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 150, 255))
    }
    upGrad.Rotation = 90

    -- LABEL CENTRAL
    local label = Instance.new("TextLabel", container)
    label.Size = UDim2.new(1, 0, 0, 28)
    label.Position = UDim2.new(0, 0, 0, 86)
    label.BackgroundTransparency = 1
    label.Text = "🚀 FLY"
    label.TextColor3 = Color3.fromRGB(100, 255, 255)
    label.TextSize = 16
    label.Font = Enum.Font.GothamBlack
    label.TextStrokeTransparency = 0.5
    label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)

    -- BOTÓN BAJAR (▼)
    local downBtn = Instance.new("TextButton", container)
    downBtn.Size = UDim2.new(1, 0, 0, 85)
    downBtn.Position = UDim2.new(0, 0, 1, -85)
    downBtn.BackgroundColor3 = Color3.fromRGB(0, 150, 220)
    downBtn.BackgroundTransparency = 0.2
    downBtn.Text = "▼\nBAJAR"
    downBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    downBtn.TextSize = 20
    downBtn.Font = Enum.Font.GothamBlack
    local downCorner = Instance.new("UICorner", downBtn)
    downCorner.CornerRadius = UDim.new(0, 18)
    local ds = Instance.new("UIStroke", downBtn)
    ds.Color = Color3.fromRGB(100, 255, 255)
    ds.Thickness = 3
    ds.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    local downGrad = Instance.new("UIGradient", downBtn)
    downGrad.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 170, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 100, 220))
    }
    downGrad.Rotation = 90

    -- EVENTOS TÁCTILES MEJORADOS
    upBtn.InputBegan:Connect(function(i)
        if i.UserInputType == Enum.UserInputType.Touch or i.UserInputType == Enum.UserInputType.MouseButton1 then
            upPressed = true
            upBtn.BackgroundTransparency = 0.05
            upBtn.Size = UDim2.new(1, 0, 0, 90)
        end
    end)
    upBtn.InputEnded:Connect(function(i)
        if i.UserInputType == Enum.UserInputType.Touch or i.UserInputType == Enum.UserInputType.MouseButton1 then
            upPressed = false
            upBtn.BackgroundTransparency = 0.2
            upBtn.Size = UDim2.new(1, 0, 0, 85)
        end
    end)
    downBtn.InputBegan:Connect(function(i)
        if i.UserInputType == Enum.UserInputType.Touch or i.UserInputType == Enum.UserInputType.MouseButton1 then
            downPressed = true
            downBtn.BackgroundTransparency = 0.05
            downBtn.Size = UDim2.new(1, 0, 0, 90)
        end
    end)
    downBtn.InputEnded:Connect(function(i)
        if i.UserInputType == Enum.UserInputType.Touch or i.UserInputType == Enum.UserInputType.MouseButton1 then
            downPressed = false
            downBtn.BackgroundTransparency = 0.2
            downBtn.Size = UDim2.new(1, 0, 0, 85)
        end
    end)
end

local function startFly()
    local char, hrp, hum = getChar()
    if not (char and hrp and hum) then
        char = LP.CharacterAdded:Wait()
        hrp = char:WaitForChild("HumanoidRootPart")
        hum = char:WaitForChild("Humanoid")
    end

    createFlyButtons()

    flyBV = Instance.new("BodyVelocity")
    flyBV.Velocity = Vector3.new(0, 0, 0)
    flyBV.MaxForce = Vector3.new(1e5, 1e5, 1e5)
    flyBV.Parent = hrp

    flyBG = Instance.new("BodyGyro")
    flyBG.MaxTorque = Vector3.new(1e5, 1e5, 1e5)
    flyBG.P = 1e4
    flyBG.D = 100
    flyBG.CFrame = hrp.CFrame
    flyBG.Parent = hrp

    safe("FlyLoop", RunService.RenderStepped:Connect(function()
        if not flyEnabled then return end
        local _, hrpC, humC = getChar()
        if not (hrpC and humC) then return end

        local cam = Camera
        local moveDir = humC.MoveDirection
        local horizontal = moveDir * flySpeed
        local vertical = 0

        if upPressed then vertical = flySpeed end
        if downPressed then vertical = -flySpeed end

        flyBV.Velocity = Vector3.new(horizontal.X, vertical + 0.05, horizontal.Z)
        flyBG.CFrame = cam.CFrame
    end))

    R:Notify({
        Title = "✅ VUELO ACTIVADO",
        Content = "🚀 Volando a " .. flySpeed .. " u/s",
        Duration = 3,
        Image = 4483362458
    })
end

local function stopFly()
    if flyBV then flyBV:Destroy() flyBV = nil end
    if flyBG then flyBG:Destroy() flyBG = nil end
    stop("FlyLoop")
    if flyGui then flyGui:Destroy() flyGui = nil end
    upPressed = false
    downPressed = false
end

FlyTab:CreateToggle({
    Name = "🚀 Activar Vuelo",
    CurrentValue = false,
    Flag = "FlyToggle",
    Callback = function(v)
        flyEnabled = v
        if v then startFly() else stopFly() end
    end
})

FlyTab:CreateSlider({
    Name = "⚡ Velocidad de Vuelo",
    Range = {10, 500},
    Increment = 5,
    Suffix = " u/s",
    CurrentValue = 50,
    Flag = "FlySpeedSlider",
    Callback = function(v) flySpeed = v end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 4: AIMBOT ASSIST
-- ═══════════════════════════════════════════════════════════
local AimbotTab = W:CreateTab("🎯 AIMBOT", 4483362458)

AimbotTab:CreateSection("🎯 Configuración de Aimbot")

local aimbotEnabled = false
local aimbotFOV = 120
local aimbotSmoothing = 6
local aimbotPrediction = 0.08
local aimbotTargetPart = "Head"
local aimbotTeamCheck = false
local aimbotShowFOV = true
local fovCircle = nil

local function createFOVCircle()
    pcall(function()
        if fovCircle then fovCircle:Remove() fovCircle = nil end
        fovCircle = Drawing.new("Circle")
        fovCircle.Thickness = 2
        fovCircle.Color = Color3.fromRGB(255, 50, 50)
        fovCircle.Filled = false
        fovCircle.Transparency = 0.6
        fovCircle.Radius = aimbotFOV
        fovCircle.Visible = false
    end)
end

local function getClosestToCenter()
    local closest, minDist = nil, aimbotFOV
    local center = Vector2.new(Camera.ViewportSize.X / 2, Camera.ViewportSize.Y / 2)

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP and plr.Character then
            if aimbotTeamCheck and plr.Team == LP.Team then continue end
            local part = plr.Character:FindFirstChild(aimbotTargetPart) or plr.Character:FindFirstChild("Head")
            local hum = plr.Character:FindFirstChildOfClass("Humanoid")
            if part and hum and hum.Health > 0 then
                local screenPos, onScreen = Camera:WorldToViewportPoint(part.Position)
                if onScreen then
                    local d = (center - Vector2.new(screenPos.X, screenPos.Y)).Magnitude
                    if d < minDist then
                        minDist = d
                        closest = plr
                    end
                end
            end
        end
    end
    return closest
end

AimbotTab:CreateToggle({
    Name = "🎯 Activar Aimbot Assist",
    CurrentValue = false,
    Flag = "AimbotToggle",
    Callback = function(v)
        aimbotEnabled = v
        if v then
            createFOVCircle()
            safe("Aimbot", RunService.RenderStepped:Connect(function()
                if not aimbotEnabled then return end
                pcall(function()
                    if fovCircle then
                        fovCircle.Position = Vector2.new(Camera.ViewportSize.X/2, Camera.ViewportSize.Y/2)
                        fovCircle.Radius = aimbotFOV
                        fovCircle.Visible = aimbotShowFOV
                    end

                    local target = getClosestToCenter()
                    if target and target.Character then
                        local part = target.Character:FindFirstChild(aimbotTargetPart) or target.Character:FindFirstChild("Head")
                        local hrp2 = target.Character:FindFirstChild("HumanoidRootPart")
                        if part and hrp2 then
                            local predicted = part.Position + (hrp2.Velocity * aimbotPrediction)
                            local current = Camera.CFrame
                            local targetCF = CFrame.new(current.Position, predicted)
                            Camera.CFrame = current:Lerp(targetCF, 1 / aimbotSmoothing)

                            if fovCircle then fovCircle.Color = Color3.fromRGB(0, 255, 0) end
                        end
                    else
                        if fovCircle then fovCircle.Color = Color3.fromRGB(255, 50, 50) end
                    end
                end)
            end))
        else
            stop("Aimbot")
            pcall(function()
                if fovCircle then fovCircle.Visible = false; fovCircle:Remove(); fovCircle = nil end
            end)
        end
    end
})

AimbotTab:CreateSlider({
    Name = "📐 Radio FOV",
    Range = {30, 400},
    Increment = 10,
    Suffix = " px",
    CurrentValue = 120,
    Flag = "AimbotFOVSlider",
    Callback = function(v) aimbotFOV = v end
})

AimbotTab:CreateSlider({
    Name = "🎚️ Suavizado",
    Range = {2, 20},
    Increment = 1,
    CurrentValue = 6,
    Flag = "AimbotSmoothSlider",
    Callback = function(v) aimbotSmoothing = v end
})

AimbotTab:CreateSlider({
    Name = "🔮 Predicción",
    Range = {0, 30},
    Increment = 1,
    Suffix = "%",
    CurrentValue = 8,
    Flag = "AimbotPredictionSlider",
    Callback = function(v) aimbotPrediction = v / 100 end
})

AimbotTab:CreateDropdown({
    Name = "🎯 Parte del Cuerpo",
    Options = {"Head", "HumanoidRootPart", "UpperTorso"},
    CurrentOption = {"Head"},
    Flag = "AimbotTargetPart",
    Callback = function(opt) if opt and opt[1] then aimbotTargetPart = opt[1] end end
})

AimbotTab:CreateToggle({
    Name = "👥 Ignorar Compañeros",
    CurrentValue = false,
    Flag = "AimbotTeamCheck",
    Callback = function(v) aimbotTeamCheck = v end
})

AimbotTab:CreateToggle({
    Name = "🔴 Mostrar Círculo FOV",
    CurrentValue = true,
    Flag = "AimbotShowFOV",
    Callback = function(v)
        aimbotShowFOV = v
        pcall(function() if fovCircle then fovCircle.Visible = v and aimbotEnabled end end)
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 5: VISUALES / ESP
-- ═══════════════════════════════════════════════════════════
local VisualsTab = W:CreateTab("👁️ VISUALES", 4483362458)

VisualsTab:CreateSection("👁️ ESP / Wallhack")

local espEnabled = false
local espFolder = nil

local function clearESP()
    if espFolder then espFolder:Destroy() end
    espFolder = Instance.new("Folder")
    espFolder.Name = "ShoweyESP_" .. math.random(10000, 99999)
    espFolder.Parent = CoreGui
end

local function createESP(player)
    if player == LP or not espFolder then return end
    local function apply(char)
        if not char then return end
        task.wait(0.5)
        local old = char:FindFirstChild("ShoweyHL")
        if old then old:Destroy() end

        local hl = Instance.new("Highlight")
        hl.Name = "ShoweyHL"
        hl.FillColor = Color3.fromRGB(0, 255, 150)
        hl.FillTransparency = 0.6
        hl.OutlineColor = Color3.fromRGB(0, 200, 255)
        hl.OutlineTransparency = 0.1
        hl.Adornee = char
        hl.Parent = espFolder

        local head = char:FindFirstChild("Head")
        if head then
            local bb = Instance.new("BillboardGui")
            bb.Size = UDim2.new(0, 200, 0, 50)
            bb.StudsOffset = Vector3.new(0, 3, 0)
            bb.AlwaysOnTop = true
            bb.Adornee = head
            bb.Parent = espFolder

            local nameL = Instance.new("TextLabel", bb)
            nameL.Size = UDim2.new(1, 0, 0.5, 0)
            nameL.BackgroundTransparency = 1
            nameL.TextColor3 = Color3.fromRGB(0, 255, 200)
            nameL.TextStrokeTransparency = 0.3
            nameL.TextSize = 14
            nameL.Font = Enum.Font.GothamBold
            nameL.Text = player.Name

            local distL = Instance.new("TextLabel", bb)
            distL.Name = "DistLabel"
            distL.Size = UDim2.new(1, 0, 0.5, 0)
            distL.Position = UDim2.new(0, 0, 0.5, 0)
            distL.BackgroundTransparency = 1
            distL.TextColor3 = Color3.fromRGB(255, 255, 100)
            distL.TextStrokeTransparency = 0.3
            distL.TextSize = 12
            distL.Font = Enum.Font.Gotham
            distL.Text = "..."

            local hpBG = Instance.new("Frame", bb)
            hpBG.Size = UDim2.new(0.8, 0, 0, 4)
            hpBG.Position = UDim2.new(0.1, 0, 1, 2)
            hpBG.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
            hpBG.BorderSizePixel = 0
            Instance.new("UICorner", hpBG).CornerRadius = UDim.new(0, 2)

            local hpFill = Instance.new("Frame", hpBG)
            hpFill.Name = "HealthFill"
            hpFill.Size = UDim2.new(1, 0, 1, 0)
            hpFill.BackgroundColor3 = Color3.fromRGB(0, 255, 100)
            hpFill.BorderSizePixel = 0
            Instance.new("UICorner", hpFill).CornerRadius = UDim.new(0, 2)
        end
    end
    if player.Character then apply(player.Character) end
    player.CharacterAdded:Connect(function(c) task.wait(1) if espEnabled then apply(c) end end)
end

local frameCounter = 0
local function updateESP()
    if not espFolder or not espEnabled then return end
    frameCounter = frameCounter + 1
    if frameCounter < 5 then return end
    frameCounter = 0

    local _, myHrp = getChar()
    if not myHrp then return end
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP and plr.Character then
            local head = plr.Character:FindFirstChild("Head")
            local hrp2 = plr.Character:FindFirstChild("HumanoidRootPart")
            local hum2 = plr.Character:FindFirstChildOfClass("Humanoid")
            if head and hrp2 then
                for _, gui in ipairs(espFolder:GetChildren()) do
                    if gui:IsA("BillboardGui") and gui.Adornee == head then
                        local dist = math.floor((myHrp.Position - hrp2.Position).Magnitude)
                        local dL = gui:FindFirstChild("DistLabel")
                        if dL then dL.Text = "⟨ " .. dist .. " studs ⟩" end
                        if hum2 then
                            for _, fr in ipairs(gui:GetDescendants()) do
                                if fr.Name == "HealthFill" then
                                    local ratio = math.clamp(hum2.Health / hum2.MaxHealth, 0, 1)
                                    fr.Size = UDim2.new(ratio, 0, 1, 0)
                                    fr.BackgroundColor3 = Color3.fromRGB(255*(1-ratio), 255*ratio, 50)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

VisualsTab:CreateToggle({
    Name = "👁️ ESP — Ver Jugadores",
    CurrentValue = false,
    Flag = "ESPToggle",
    Callback = function(v)
        espEnabled = v
        if v then
            clearESP()
            for _, p in ipairs(Players:GetPlayers()) do createESP(p) end
            Players.PlayerAdded:Connect(function(p) if espEnabled then createESP(p) end end)
            safe("ESPUpdate", RunService.RenderStepped:Connect(updateESP))
        else
            stop("ESPUpdate")
            clearESP()
        end
    end
})

VisualsTab:CreateSection("💡 Iluminación")

local origAmbient = Lighting.Ambient
local origBright = Lighting.Brightness
local origFog = Lighting.FogEnd
local origOutdoor = Lighting.OutdoorAmbient

VisualsTab:CreateToggle({
    Name = "💡 Fullbright",
    CurrentValue = false,
    Flag = "FullbrightToggle",
    Callback = function(v)
        if v then
            Lighting.Ambient = Color3.fromRGB(200, 200, 200)
            Lighting.Brightness = 2
            Lighting.FogEnd = 100000
            Lighting.OutdoorAmbient = Color3.fromRGB(200, 200, 200)
            Lighting.GlobalShadows = false
            for _, e in ipairs(Lighting:GetChildren()) do
                if e:IsA("ColorCorrectionEffect") or e:IsA("BloomEffect") or e:IsA("BlurEffect") then
                    e.Enabled = false
                end
            end
        else
            Lighting.Ambient = origAmbient
            Lighting.Brightness = origBright
            Lighting.FogEnd = origFog
            Lighting.OutdoorAmbient = origOutdoor
            Lighting.GlobalShadows = true
            for _, e in ipairs(Lighting:GetChildren()) do
                if e:IsA("ColorCorrectionEffect") or e:IsA("BloomEffect") or e:IsA("BlurEffect") then
                    e.Enabled = true
                end
            end
        end
    end
})

VisualsTab:CreateSlider({
    Name = "📷 Campo de Visión (FOV)",
    Range = {30, 120},
    Increment = 1,
    Suffix = "°",
    CurrentValue = 70,
    Flag = "FOVSlider",
    Callback = function(v) Camera.FieldOfView = v end
})

VisualsTab:CreateSection("📏 Otros Visuales")

-- Tracers
local tracersEnabled = false
local tracerLines = {}

VisualsTab:CreateToggle({
    Name = "📏 Tracers",
    CurrentValue = false,
    Flag = "TracersToggle",
    Callback = function(v)
        tracersEnabled = v
        if v then
            safe("Tracers", RunService.RenderStepped:Connect(function()
                if not tracersEnabled then return end
                for _, line in pairs(tracerLines) do pcall(function() line:Remove() end) end
                tracerLines = {}
                for _, plr in ipairs(Players:GetPlayers()) do
                    if plr ~= LP and plr.Character then
                        local hrp2 = plr.Character:FindFirstChild("HumanoidRootPart")
                        local hum2 = plr.Character:FindFirstChildOfClass("Humanoid")
                        if hrp2 and hum2 and hum2.Health > 0 then
                            local sp, onS = Camera:WorldToScreenPoint(hrp2.Position)
                            if onS then
                                pcall(function()
                                    local l = Drawing.new("Line")
                                    l.From = Vector2.new(Camera.ViewportSize.X/2, Camera.ViewportSize.Y)
                                    l.To = Vector2.new(sp.X, sp.Y)
                                    l.Color = Color3.fromRGB(255, 50, 50)
                                    l.Thickness = 1.5
                                    l.Transparency = 0.8
                                    l.Visible = true
                                    table.insert(tracerLines, l)
                                end)
                            end
                        end
                    end
                end
            end))
        else
            stop("Tracers")
            for _, line in pairs(tracerLines) do pcall(function() line:Remove() end) end
            tracerLines = {}
        end
    end
})

-- Hitbox Expander
VisualsTab:CreateSlider({
    Name = "📦 Hitbox Expander",
    Range = {1, 20},
    Increment = 1,
    Suffix = "x",
    CurrentValue = 1,
    Flag = "HitboxSlider",
    Callback = function(v)
        for _, plr in ipairs(Players:GetPlayers()) do
            if plr ~= LP and plr.Character then
                local hrp2 = plr.Character:FindFirstChild("HumanoidRootPart")
                if hrp2 then
                    pcall(function()
                        hrp2.Size = Vector3.new(2*v, 2*v, 1*v)
                        hrp2.Transparency = v > 1 and 0.7 or 1
                        hrp2.CanCollide = false
                    end)
                end
            end
        end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 6: EMOTES
-- ═══════════════════════════════════════════════════════════
local EmotesTab = W:CreateTab("💃 EMOTES", 4483362458)

EmotesTab:CreateSection("💃 Biblioteca de Emotes")

local currentTrack = nil

local emotes = {
    {"🕺 Default Dance", "5918726674"},
    {"💃 Floss", "5917459365"},
    {"🎵 Orange Justice", "5918643831"},
    {"🏃 Naruto Run", "5918637867"},
    {"🎶 Electro Shuffle", "5918626665"},
    {"🤸 Backflip", "5918621963"},
    {"🤠 Hype Dance", "5918622453"},
    {"💀 Skull Breaker", "5918644081"},
    {"🤪 Crazy Dance", "5918643510"},
    {"🎸 Air Guitar", "5918621820"},
    {"💪 Flex", "5915773155"},
    {"😎 Swag Walk", "5918622109"},
    {"🤣 Laugh", "5915693819"},
    {"👋 Wave", "5915694581"},
    {"🌪️ Tornado Spin", "5918622285"},
    {"🧘 Meditation", "5918638240"},
    {"😴 Sleep", "5918621712"},
    {"🐔 Chicken Dance", "5918622609"},
    {"🕴️ T-Pose", "5918622777"},
    {"🧟 Zombie Walk", "5918644700"},
}

local function playEmote(id)
    local _, _, hum = getChar()
    if not hum then return end
    if currentTrack then pcall(function() currentTrack:Stop() end) end
    pcall(function()
        local anim = Instance.new("Animation")
        anim.AnimationId = "rbxassetid://" .. id
        local animator = hum:FindFirstChildOfClass("Animator") or Instance.new("Animator", hum)
        currentTrack = animator:LoadAnimation(anim)
        currentTrack.Priority = Enum.AnimationPriority.Action4
        currentTrack.Looped = true
        currentTrack:Play()
    end)
end

for _, e in ipairs(emotes) do
    EmotesTab:CreateButton({
        Name = e[1],
        Callback = function() playEmote(e[2]) end
    })
end

EmotesTab:CreateSection("⚙️ Control de Emotes")

EmotesTab:CreateButton({
    Name = "⏹️ Detener Emote",
    Callback = function()
        if currentTrack then pcall(function() currentTrack:Stop() end) currentTrack = nil end
    end
})

EmotesTab:CreateButton({
    Name = "🎲 Emote Aleatorio",
    Callback = function()
        local rand = emotes[math.random(1, #emotes)]
        R:Notify({
            Title = "🎲 EMOTE ALEATORIO",
            Content = rand[1],
            Duration = 2,
            Image = 4483362458
        })
        playEmote(rand[2])
    end
})

EmotesTab:CreateInput({
    Name = "🔢 ID Personalizado",
    PlaceholderText = "Pega el ID de animación...",
    RemoveTextAfterFocusLost = false,
    Flag = "CustomEmoteID",
    Callback = function(text)
        if text and text ~= "" then
            text = text:gsub("%D", "")
            if text ~= "" then playEmote(text) end
        end
    end
})

EmotesTab:CreateSlider({
    Name = "⏩ Velocidad de Reproducción",
    Range = {1, 50},
    Increment = 1,
    Suffix = "%",
    CurrentValue = 10,
    Flag = "EmoteSpeedSlider",
    Callback = function(v)
        if currentTrack then pcall(function() currentTrack:AdjustSpeed(v / 10) end) end
    end
})

EmotesTab:CreateButton({
    Name = "🔄 Resetear Animaciones",
    Callback = function()
        local _, _, hum = getChar()
        if hum then
            pcall(function()
                local animator = hum:FindFirstChildOfClass("Animator")
                if animator then
                    for _, track in ipairs(animator:GetPlayingAnimationTracks()) do track:Stop() end
                end
            end)
        end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 7: COMBATE
-- ═══════════════════════════════════════════════════════════
local CombatTab = W:CreateTab("🔫 COMBATE", 4483362458)

CombatTab:CreateSection("⚔️ Kill Aura")

local killAuraEnabled = false
local killAuraRange = 15

CombatTab:CreateToggle({
    Name = "⚔️ Kill Aura",
    CurrentValue = false,
    Flag = "KillAuraToggle",
    Callback = function(v)
        killAuraEnabled = v
        if v then
            task.spawn(function()
                while killAuraEnabled do
                    local _, myHrp = getChar()
                    if myHrp then
                        for _, plr in ipairs(Players:GetPlayers()) do
                            if not killAuraEnabled then break end
                            if plr ~= LP and plr.Character then
                                local hrp2 = plr.Character:FindFirstChild("HumanoidRootPart")
                                local hum2 = plr.Character:FindFirstChildOfClass("Humanoid")
                                if hrp2 and hum2 and hum2.Health > 0 then
                                    local dist = (myHrp.Position - hrp2.Position).Magnitude
                                    if dist <= killAuraRange then
                                        pcall(function()
                                            firetouchinterest(myHrp, hrp2, 0)
                                            task.wait()
                                            firetouchinterest(myHrp, hrp2, 1)
                                        end)
                                        pcall(function()
                                            myHrp.CFrame = CFrame.new(myHrp.Position, hrp2.Position)
                                        end)
                                    end
                                end
                            end
                        end
                    end
                    task.wait(0.15)
                end
            end)
        end
    end
})

CombatTab:CreateSlider({
    Name = "📏 Rango Kill Aura",
    Range = {5, 50},
    Increment = 1,
    Suffix = " studs",
    CurrentValue = 15,
    Flag = "KillAuraRangeSlider",
    Callback = function(v) killAuraRange = v end
})

CombatTab:CreateSection("🗡️ Habilidades de Combate")

CombatTab:CreateButton({
    Name = "🗡️ Backstab TP",
    Callback = function()
        if targetPlayer == "" then 
            R:Notify({
                Title = "❌ ERROR",
                Content = "⚠️ Selecciona un jugador primero",
                Duration = 3,
                Image = 4483362458
            })
            return 
        end
        local p = Players:FindFirstChild(targetPlayer)
        local _, myHrp = getChar()
        if p and p.Character and p.Character:FindFirstChild("HumanoidRootPart") and myHrp then
            myHrp.CFrame = p.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, 3)
        end
    end
})

CombatTab:CreateButton({
    Name = "⚡ Speed Hit",
    Callback = function()
        local _, myHrp = getChar()
        if not myHrp then return end
        local original = myHrp.CFrame
        for _, plr in ipairs(Players:GetPlayers()) do
            if plr ~= LP and plr.Character then
                local hrp2 = plr.Character:FindFirstChild("HumanoidRootPart")
                if hrp2 then
                    myHrp.CFrame = hrp2.CFrame
                    pcall(function()
                        firetouchinterest(myHrp, hrp2, 0)
                        task.wait()
                        firetouchinterest(myHrp, hrp2, 1)
                    end)
                    task.wait(0.05)
                end
            end
        end
        myHrp.CFrame = original
    end
})

CombatTab:CreateSection("🛡️ Protección en Combate")

CombatTab:CreateToggle({
    Name = "🧱 Anti-Knockback",
    CurrentValue = false,
    Flag = "AntiKBToggle",
    Callback = function(v)
        if v then
            safe("AntiKB", RunService.Heartbeat:Connect(function()
                local _, hrp = getChar()
                if hrp then hrp.Velocity = Vector3.new(0, math.min(hrp.Velocity.Y, 0), 0) end
            end))
        else stop("AntiKB") end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 8: UTILIDADES
-- ═══════════════════════════════════════════════════════════
local UtilsTab = W:CreateTab("🎮 UTILIDADES", 4483362458)

UtilsTab:CreateSection("🔧 Herramientas Generales")

UtilsTab:CreateToggle({
    Name = "🔓 Anti-AFK",
    CurrentValue = false,
    Flag = "AntiAFKToggle",
    Callback = function(v)
        if v then
            local vu = game:GetService("VirtualUser")
            safe("AntiAFK", LP.Idled:Connect(function()
                vu:Button2Down(Vector2.new(0,0), Camera.CFrame)
                task.wait(1)
                vu:Button2Up(Vector2.new(0,0), Camera.CFrame)
            end))
        else stop("AntiAFK") end
    end
})

local clickTPEnabled = false
UtilsTab:CreateToggle({
    Name = "🖱️ Click Teleport",
    CurrentValue = false,
    Flag = "ClickTPToggle",
    Callback = function(v)
        clickTPEnabled = v
        if v then
            local mouse = LP:GetMouse()
            safe("ClickTP", mouse.Button1Down:Connect(function()
                if clickTPEnabled and mouse.Target then
                    local _, hrp = getChar()
                    if hrp then hrp.CFrame = CFrame.new(mouse.Hit.X, mouse.Hit.Y + 5, mouse.Hit.Z) end
                end
            end))
        else stop("ClickTP") end
    end
})

UtilsTab:CreateSection("🧊 Control del Personaje")

UtilsTab:CreateButton({
    Name = "🧊 Congelar Personaje",
    Callback = function()
        local _, hrp = getChar()
        if hrp then hrp.Anchored = true end
    end
})

UtilsTab:CreateButton({
    Name = "🔥 Descongelar",
    Callback = function()
        local _, hrp = getChar()
        if hrp then hrp.Anchored = false end
    end
})

UtilsTab:CreateButton({
    Name = "💀 Respawnear",
    Callback = function()
        local _, _, hum = getChar()
        if hum then hum.Health = 0 end
    end
})

UtilsTab:CreateSection("💾 Posiciones")

local savedPos = nil
UtilsTab:CreateButton({
    Name = "💾 Guardar Posición",
    Callback = function()
        local _, hrp = getChar()
        if hrp then 
            savedPos = hrp.CFrame
            R:Notify({
                Title = "✅ POSICIÓN GUARDADA",
                Content = "📍 Posición almacenada correctamente",
                Duration = 2,
                Image = 4483362458
            })
        end
    end
})

UtilsTab:CreateButton({
    Name = "📂 Cargar Posición",
    Callback = function()
        if savedPos then
            local _, hrp = getChar()
            if hrp then hrp.CFrame = savedPos end
        end
    end
})

UtilsTab:CreateSection("🤸 Movimiento Especial")

UtilsTab:CreateToggle({
    Name = "🐸 Auto-Jump",
    CurrentValue = false,
    Flag = "AutoJumpToggle",
    Callback = function(v)
        if v then
            safe("AutoJump", RunService.Heartbeat:Connect(function()
                local _, _, hum = getChar()
                if hum and hum:GetState() ~= Enum.HumanoidStateType.Freefall then hum.Jump = true end
            end))
        else stop("AutoJump") end
    end
})

UtilsTab:CreateSection("💬 Chat")

local chatSpamOn = false
local chatMsg = "Showey Hub v3.1 🚀 | MX 🇲🇽 GT 🇬🇹"
UtilsTab:CreateToggle({
    Name = "💬 Chat Spam",
    CurrentValue = false,
    Flag = "ChatSpamToggle",
    Callback = function(v)
        chatSpamOn = v
        if v then
            task.spawn(function()
                while chatSpamOn do
                    pcall(function() ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(chatMsg, "All") end)
                    task.wait(2)
                end
            end)
        end
    end
})

UtilsTab:CreateInput({
    Name = "📝 Mensaje Spam",
    PlaceholderText = "Escribe tu mensaje aquí...",
    RemoveTextAfterFocusLost = false,
    Flag = "ChatSpamMessage",
    Callback = function(t) if t and t ~= "" then chatMsg = t end end
})

UtilsTab:CreateSection("📊 Información")

UtilsTab:CreateButton({
    Name = "📊 Info del Servidor",
    Callback = function()
        local ping = 0
        pcall(function() ping = math.floor(game:GetService("Stats").Network.ServerStatsItem["Data Ping"]:GetValue()) end)
        local fps = math.floor(1 / RunService.RenderStepped:Wait())
        R:Notify({
            Title = "📊 INFO DEL SERVIDOR",
            Content = string.format("📡 Ping: %dms\n🎮 FPS: %d\n👥 Jugadores: %d/%d", ping, fps, #Players:GetPlayers(), Players.MaxPlayers),
            Duration = 6,
            Image = 4483362458
        })
    end
})

UtilsTab:CreateInput({
    Name = "🗺️ Teleport a Coordenadas",
    PlaceholderText = "100,50,200",
    RemoveTextAfterFocusLost = false,
    Flag = "CoordTPInput",
    Callback = function(text)
        if text and text ~= "" then
            local coords = text:split(",")
            if #coords >= 3 then
                local x, y, z = tonumber(coords[1]), tonumber(coords[2]), tonumber(coords[3])
                if x and y and z then
                    local _, hrp = getChar()
                    if hrp then hrp.CFrame = CFrame.new(x, y, z) end
                end
            end
        end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 9: MUNDO
-- ═══════════════════════════════════════════════════════════
local WorldTab = W:CreateTab("🌍 MUNDO", 4483362458)

WorldTab:CreateSection("🌤️ Ambiente")

WorldTab:CreateSlider({
    Name = "🕐 Hora del Día",
    Range = {0, 24},
    Increment = 1,
    Suffix = " hrs",
    CurrentValue = 12,
    Flag = "TimeOfDaySlider",
    Callback = function(v) Lighting.ClockTime = v end
})

WorldTab:CreateButton({
    Name = "🌫️ Eliminar Niebla",
    Callback = function()
        Lighting.FogEnd = 1e10
        Lighting.FogStart = 1e10
        for _, v in ipairs(Lighting:GetChildren()) do
            if v:IsA("Atmosphere") then v.Density = 0 end
        end
    end
})

WorldTab:CreateSection("🗑️ Optimización")

WorldTab:CreateButton({
    Name = "🗑️ Eliminar Efectos",
    Callback = function()
        local c = 0
        for _, v in ipairs(Workspace:GetDescendants()) do
            if v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Fire") or v:IsA("Smoke") or v:IsA("Sparkles") then
                v:Destroy(); c = c + 1
            end
        end
        R:Notify({
            Title = "✅ MUNDO OPTIMIZADO",
            Content = "🗑️ " .. c .. " efectos eliminados",
            Duration = 3,
            Image = 4483362458
        })
    end
})

WorldTab:CreateButton({
    Name = "🌿 Eliminar Vegetación",
    Callback = function()
        local c = 0
        for _, v in ipairs(Workspace:GetDescendants()) do
            if v:IsA("MeshPart") or v:IsA("UnionOperation") then
                local n = v.Name:lower()
                if n:find("grass") or n:find("tree") or n:find("bush") or n:find("leaf") or n:find("plant") or n:find("flower") then
                    v:Destroy(); c = c + 1
                end
            end
        end
        R:Notify({
            Title = "✅ VEGETACIÓN ELIMINADA",
            Content = "🌿 " .. c .. " objetos eliminados",
            Duration = 3,
            Image = 4483362458
        })
    end
})

WorldTab:CreateButton({
    Name = "🔇 Silenciar Sonidos",
    Callback = function()
        local c = 0
        for _, v in ipairs(Workspace:GetDescendants()) do
            if v:IsA("Sound") then v.Volume = 0; v.Playing = false; c = c + 1 end
        end
        R:Notify({
            Title = "✅ SONIDOS SILENCIADOS",
            Content = "🔇 " .. c .. " sonidos apagados",
            Duration = 3,
            Image = 4483362458
        })
    end
})

WorldTab:CreateButton({
    Name = "🌊 Reducir Agua",
    Callback = function()
        pcall(function()
            local t = Workspace:FindFirstChildOfClass("Terrain")
            if t then t.WaterWaveSize = 0; t.WaterWaveSpeed = 0; t.WaterReflectance = 0; t.WaterTransparency = 1 end
        end)
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 10: SEGURIDAD
-- ═══════════════════════════════════════════════════════════
local SecurityTab = W:CreateTab("🛡️ SEGURIDAD", 4483362458)

SecurityTab:CreateSection("🛡️ Protecciones")

SecurityTab:CreateToggle({
    Name = "🛡️ Anti-Cheat Bypass",
    CurrentValue = true,
    Flag = "AntiCheatBypass",
    Callback = function(v)
        if v then
            R:Notify({
                Title = "🛡️ PROTECCIÓN ACTIVA",
                Content = "✅ Sistema anti-detección activado",
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

SecurityTab:CreateToggle({
    Name = "🔇 Bloquear Anti-Cheat",
    CurrentValue = false,
    Flag = "BlockAntiCheat",
    Callback = function(v)
        if v then
            pcall(function()
                for _, r in ipairs(ReplicatedStorage:GetDescendants()) do
                    if r:IsA("RemoteEvent") or r:IsA("RemoteFunction") then
                        local n = r.Name:lower()
                        if n:find("detect") or n:find("cheat") or n:find("anti") or n:find("kick") or n:find("ban") then
                            pcall(function() r:Destroy() end)
                        end
                    end
                end
            end)
            R:Notify({
                Title = "🛡️ ANTI-CHEAT BLOQUEADO",
                Content = "✅ Remotes bloqueados",
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

SecurityTab:CreateSection("🪂 Anti-Muerte")

local antiFallEnabled = false
SecurityTab:CreateToggle({
    Name = "🪂 Anti-Caída",
    CurrentValue = false,
    Flag = "AntiFallToggle",
    Callback = function(v)
        antiFallEnabled = v
        if v then
            safe("AntiFall", RunService.RenderStepped:Connect(function()
                if not antiFallEnabled then return end
                local _, hrp, hum = getChar()
                if hrp and hum then
                    if hrp.Position.Y < -50 then
                        hrp.CFrame = CFrame.new(hrp.Position.X, 100, hrp.Position.Z)
                        hrp.Velocity = Vector3.new(0, 0, 0)
                    end
                    hum:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
                    hum:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
                end
            end))
        else stop("AntiFall") end
    end
})

SecurityTab:CreateToggle({
    Name = "🦴 Anti-Ragdoll",
    CurrentValue = false,
    Flag = "AntiRagdollToggle",
    Callback = function(v)
        if v then
            safe("AntiRagdoll", RunService.Heartbeat:Connect(function()
                local _, _, hum = getChar()
                if hum then
                    hum:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
                    hum:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
                    hum:ChangeState(Enum.HumanoidStateType.GettingUp)
                end
            end))
        else stop("AntiRagdoll") end
    end
})

SecurityTab:CreateButton({
    Name = "⚡ God Mode",
    Callback = function()
        local _, _, hum = getChar()
        if hum then
            pcall(function()
                safe("GodMode", hum.HealthChanged:Connect(function(h)
                    if h < hum.MaxHealth then hum.Health = hum.MaxHealth end
                end))
            end)
            R:Notify({
                Title = "⚡ GOD MODE ACTIVADO",
                Content = "✅ Protección total activada",
                Duration = 3,
                Image = 4483362458
            })
        end
    end
})

SecurityTab:CreateSection("🌀 Otras Protecciones")

SecurityTab:CreateToggle({
    Name = "🕳️ Anti-Void",
    CurrentValue = false,
    Flag = "AntiVoidToggle",
    Callback = function(v)
        if v then
            local p = Instance.new("Part")
            p.Name = "ShoweyAntiVoid"
            p.Size = Vector3.new(10000, 1, 10000)
            p.Position = Vector3.new(0, -200, 0)
            p.Anchored = true
            p.Transparency = 1
            p.CanCollide = true
            p.Parent = Workspace
        else
            for _, v2 in ipairs(Workspace:GetChildren()) do
                if v2.Name == "ShoweyAntiVoid" then v2:Destroy() end
            end
        end
    end
})

SecurityTab:CreateToggle({
    Name = "🌀 Anti-Fling",
    CurrentValue = false,
    Flag = "AntiFlingToggle",
    Callback = function(v)
        if v then
            safe("AntiFling", RunService.Heartbeat:Connect(function()
                local _, hrp = getChar()
                if hrp and hrp.Velocity.Magnitude > 200 then
                    hrp.Velocity = Vector3.new(0, 0, 0)
                    hrp.RotVelocity = Vector3.new(0, 0, 0)
                end
            end))
        else stop("AntiFling") end
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 11: iOS BOOST
-- ═══════════════════════════════════════════════════════════
local iOSTab = W:CreateTab("📱 iOS BOOST", 4483362458)

iOSTab:CreateSection("🚀 Optimización iOS")

iOSTab:CreateButton({
    Name = "🚀 Máximo Rendimiento",
    Callback = function()
        pcall(function() settings().Rendering.QualityLevel = Enum.QualityLevel.Level01 end)
        local c = 0
        for _, v in ipairs(Workspace:GetDescendants()) do
            if v:IsA("ParticleEmitter") or v:IsA("Trail") or v:IsA("Fire") or v:IsA("Smoke") or v:IsA("Sparkles") or v:IsA("Beam") then
                v.Enabled = false; c = c + 1
            end
        end
        Lighting.GlobalShadows = false
        Lighting.FogEnd = 1e10
        for _, v in ipairs(Lighting:GetChildren()) do
            if v:IsA("BloomEffect") or v:IsA("BlurEffect") or v:IsA("DepthOfFieldEffect") or v:IsA("SunRaysEffect") then v.Enabled = false end
            if v:IsA("Atmosphere") then v.Density = 0 end
        end
        for _, v in ipairs(Workspace:GetDescendants()) do
            if v:IsA("Decal") or v:IsA("Texture") then v.Transparency = 1 end
        end
        R:Notify({
            Title = "🚀 BOOST MÁXIMO",
            Content = "✅ " .. c .. " efectos desactivados",
            Duration = 4,
            Image = 4483362458
        })
    end
})

iOSTab:CreateButton({
    Name = "🧹 Limpiar Memoria",
    Callback = function()
        pcall(function() collectgarbage("collect"); collectgarbage("collect") end)
        R:Notify({
            Title = "🧹 MEMORIA LIMPIADA",
            Content = "✅ Limpieza completada",
            Duration = 3,
            Image = 4483362458
        })
    end
})

iOSTab:CreateButton({
    Name = "📊 Rendimiento",
    Callback = function()
        local fps = math.floor(1 / RunService.RenderStepped:Wait())
        local mem = math.floor(collectgarbage("count") / 1024 * 100) / 100
        local ping = 0
        pcall(function() ping = math.floor(game:GetService("Stats").Network.ServerStatsItem["Data Ping"]:GetValue()) end)
        R:Notify({
            Title = "📊 RENDIMIENTO",
            Content = string.format("🎮 FPS: %d\n💾 RAM: %.1f MB\n📡 Ping: %dms", fps, mem, ping),
            Duration = 6,
            Image = 4483362458
        })
    end
})

iOSTab:CreateToggle({
    Name = "📱 FPS Unlocker (120 FPS)",
    CurrentValue = false,
    Flag = "FPSUnlocker",
    Callback = function(v)
        pcall(function() setfpscap(v and 120 or 60) end)
    end
})

iOSTab:CreateButton({
    Name = "🔋 Modo Ahorro de Batería",
    Callback = function()
        pcall(function() settings().Rendering.QualityLevel = Enum.QualityLevel.Level01 end)
        Lighting.GlobalShadows = false
        for _, v in ipairs(Lighting:GetChildren()) do
            if v:IsA("PostEffect") then v.Enabled = false end
        end
        R:Notify({
            Title = "🔋 AHORRO ACTIVADO",
            Content = "✅ Batería optimizada",
            Duration = 3,
            Image = 4483362458
        })
    end
})

-- ═══════════════════════════════════════════════════════════
-- TAB 12: EXPERIMENTAL
-- ═══════════════════════════════════════════════════════════
local ExpTab = W:CreateTab("🧪 EXPERIMENTAL", 4483362458)

ExpTab:CreateSection("🫥 Visibilidad")

ExpTab:CreateButton({
    Name = "🫥 Invisibilidad",
    Callback = function()
        local char = LP.Character
        if char then
            for _, part in ipairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then part.Transparency = 1 end
                if part:IsA("Decal") then part.Transparency = 1 end
                if part:IsA("Accessory") then
                    local h = part:FindFirstChild("Handle")
                    if h then h.Transparency = 1 end
                end
            end
        end
    end
})

ExpTab:CreateButton({
    Name = "👤 Restaurar Visibilidad",
    Callback = function()
        local char = LP.Character
        if char then
            for _, part in ipairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then part.Transparency = 0 end
                if part:IsA("Decal") then part.Transparency = 0 end
                if part:IsA("Accessory") then
                    local h = part:FindFirstChild("Handle")
                    if h then h.Transparency = 0 end
                end
            end
        end
    end
})

ExpTab:CreateSection("📏 Escala")

ExpTab:CreateSlider({
    Name = "📏 Escala del Personaje",
    Range = {1, 50},
    Increment = 5,
    Suffix = "%",
    CurrentValue = 10,
    Flag = "CharacterScaleSlider",
    Callback = function(v)
        local val = v / 10
        local _, _, hum = getChar()
        if hum then
            pcall(function()
                local bd = hum:FindFirstChild("BodyDepthScale")
                local bh = hum:FindFirstChild("BodyHeightScale")
                local bw = hum:FindFirstChild("BodyWidthScale")
                local hs = hum:FindFirstChild("HeadScale")
                if bd then bd.Value = val end
                if bh then bh.Value = val end
                if bw then bw.Value = val end
                if hs then hs.Value = val end
            end)
        end
    end
})

ExpTab:CreateSection("🌀 Movimientos Especiales")

local spinEnabled = false
local spinSpeed = 10
ExpTab:CreateToggle({
    Name = "🌀 Modo Spin",
    CurrentValue = false,
    Flag = "SpinToggle",
    Callback = function(v)
        spinEnabled = v
        if v then
            safe("Spin", RunService.RenderStepped:Connect(function()
                if not spinEnabled then return end
                local _, hrp = getChar()
                if hrp then hrp.CFrame = hrp.CFrame * CFrame.Angles(0, math.rad(spinSpeed), 0) end
            end))
        else stop("Spin") end
    end
})

ExpTab:CreateSlider({
    Name = "🌀 Velocidad de Giro",
    Range = {1, 50},
    Increment = 1,
    Suffix = "°",
    CurrentValue = 10,
    Flag = "SpinSpeedSlider",
    Callback = function(v) spinSpeed = v end
})

ExpTab:CreateToggle({
    Name = "🪐 Orbitar Jugador",
    CurrentValue = false,
    Flag = "OrbitToggle",
    Callback = function(v)
        if v and targetPlayer ~= "" then
            local angle = 0
            safe("Orbit", RunService.RenderStepped:Connect(function(dt)
                local p = Players:FindFirstChild(targetPlayer)
                if p and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
                    local _, myHrp = getChar()
                    if myHrp then
                        angle = angle + (2 * dt)
                        local tp = p.Character.HumanoidRootPart.Position
                        myHrp.CFrame = CFrame.new(tp.X + math.cos(angle)*15, tp.Y, tp.Z + math.sin(angle)*15)
                    end
                end
            end))
        else stop("Orbit") end
    end
})

ExpTab:CreateSection("🧱 Creación")

ExpTab:CreateButton({
    Name = "🧱 Crear Plataforma",
    Callback = function()
        local _, hrp = getChar()
        if hrp then
            local p = Instance.new("Part")
            p.Size = Vector3.new(15, 1, 15)
            p.Position = hrp.Position - Vector3.new(0, 3.5, 0)
            p.Anchored = true
            p.BrickColor = BrickColor.new("Really black")
            p.Material = Enum.Material.Neon
            p.Transparency = 0.3
            p.Parent = Workspace
            task.delay(30, function() if p then p:Destroy() end end)
        end
    end
})

ExpTab:CreateSection("💰 Auto-Recolección")

ExpTab:CreateToggle({
    Name = "💰 Auto-Collect Items",
    CurrentValue = false,
    Flag = "AutoCollectToggle",
    Callback = function(v)
        if v then
            task.spawn(function()
                while v do
                    local _, myHrp = getChar()
                    if myHrp then
                        for _, item in ipairs(Workspace:GetDescendants()) do
                            if item:IsA("BasePart") then
                                local n = item.Name:lower()
                                if n:find("coin") or n:find("gem") or n:find("orb") or n:find("pickup") or
                                   n:find("collect") or n:find("drop") or n:find("loot") or n:find("cash") or
                                   n:find("money") or n:find("token") or n:find("star") or n:find("diamond") then
                                    if (myHrp.Position - item.Position).Magnitude < 200 then
                                        pcall(function() item.CFrame = myHrp.CFrame end)
                                        pcall(function()
                                            firetouchinterest(myHrp, item, 0)
                                            task.wait()
                                            firetouchinterest(myHrp, item, 1)
                                        end)
                                    end
                                end
                            end
                        end
                    end
                    task.wait(0.5)
                end
            end)
        end
    end
})

ExpTab:CreateSection("💀 Modificación de Hitbox")

ExpTab:CreateSlider({
    Name = "💀 Tamaño Cabezas Enemigas",
    Range = {1, 100},
    Increment = 5,
    Suffix = "%",
    CurrentValue = 10,
    Flag = "HeadSizeSlider",
    Callback = function(v)
        local val = v / 10
        for _, plr in ipairs(Players:GetPlayers()) do
            if plr ~= LP and plr.Character then
                local head = plr.Character:FindFirstChild("Head")
                if head then
                    pcall(function()
                        head.Size = Vector3.new(2*val, 1*val, 1*val)
                        local mesh = head:FindFirstChildOfClass("SpecialMesh")
                        if mesh then mesh.Scale = Vector3.new(1.25*val, 1.25*val, 1.25*val) end
                    end)
                end
            end
        end
    end
})

-- ═══════════════════════════════════════════════════════════
-- CRÉDITOS EN TODAS LAS TABS
-- ═══════════════════════════════════════════════════════════
local allTabs = {PlayerTab, PhysicsTab, FlyTab, AimbotTab, VisualsTab, EmotesTab, CombatTab, UtilsTab, WorldTab, SecurityTab, iOSTab, ExpTab}
for _, t in ipairs(allTabs) do
    pcall(function()
        t:CreateSection("⚡ Créditos")
        t:CreateParagraph({
            Title = "⚡ SHOWEY HUB v3.1",
            Content = "📱 Optimizado para Delta iOS\n🇲🇽 MX | 🇬🇹 GT\n💬 discord.gg/showey"
        })
    end)
end

R:Notify({
    Title = "✅ SHOWEY HUB v3.1 CARGADO",
    Content = "🚀 Todos los módulos activos | 📱 Delta iOS Ready",
    Duration = 5,
    Image = 4483362458
})

pcall(function() R:LoadConfiguration() end)
`;
