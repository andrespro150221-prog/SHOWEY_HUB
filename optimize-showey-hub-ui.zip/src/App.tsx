import { useMemo, useRef, useState } from "react";
import { LUA_SCRIPT, SCRIPT_KEY, DISCORD_LINK } from "./script";

/* ────────────────────────── helpers ────────────────────────── */
function copyText(text: string): Promise<boolean> {
  if (navigator.clipboard?.writeText) {
    return navigator.clipboard
      .writeText(text)
      .then(() => true)
      .catch(() => legacyCopy(text));
  }
  return Promise.resolve(legacyCopy(text));
}
function legacyCopy(text: string): boolean {
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

/* ────────────────────────── data ────────────────────────── */
const TABS = [
  { icon: "👥", name: "JUGADORES", desc: "Teleport, spectate, seguir y TP a todos" },
  { icon: "⚡", name: "FÍSICAS", desc: "Velocidad, súper salto, noclip, gravedad" },
  { icon: "🚀", name: "VOLAR", desc: "Fly corregido con botones táctiles ▲▼" },
  { icon: "🎯", name: "AIMBOT", desc: "FOV, suavizado, predicción y team check" },
  { icon: "👁️", name: "VISUALES", desc: "ESP, wallhack, tracers y fullbright" },
  { icon: "💃", name: "EMOTES", desc: "20+ bailes + IDs personalizados" },
  { icon: "🔫", name: "COMBATE", desc: "Kill aura, backstab TP, anti-knockback" },
  { icon: "🎮", name: "UTILIDADES", desc: "Anti-AFK, click TP, chat, posiciones" },
  { icon: "🌍", name: "MUNDO", desc: "Hora, niebla, optimización del mapa" },
  { icon: "🛡️", name: "SEGURIDAD", desc: "God mode, anti-void, anti-fling" },
  { icon: "📱", name: "iOS BOOST", desc: "120 FPS, ahorro de batería, limpieza RAM" },
  { icon: "🧪", name: "EXPERIMENTAL", desc: "Invisibilidad, spin, orbit, auto-collect" },
];

const STEPS = [
  { n: "01", icon: "📲", title: "Abre Delta en tu iPhone", desc: "Inicia Delta Executor iOS y entra a tu juego de Roblox." },
  { n: "02", icon: "📋", title: "Copia el script", desc: "Toca el botón «COPIAR SCRIPT» de esta página. Se copia completo al portapapeles." },
  { n: "03", icon: "⌨️", title: "Pega y ejecuta", desc: "Pega el script en el editor de Delta y presiona Execute ▶." },
  { n: "04", icon: "🔐", title: "Ingresa la key", desc: "Escribe tu clave privada en el sistema de verificación y ¡a disfrutar! ⚡" },
];

/* ────────────────────────── components ────────────────────────── */
function CopyButton({
  text,
  label,
  copiedLabel,
  className,
}: {
  text: string;
  label: string;
  copiedLabel: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | null>(null);

  const onCopy = async () => {
    const ok = await copyText(text);
    if (ok) {
      setCopied(true);
      if (timer.current) window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setCopied(false), 2200);
    }
  };

  return (
    <button
      onClick={onCopy}
      className={
        className ??
        "w-full rounded-2xl px-6 py-4 font-black text-base tracking-wide text-slate-950 bg-gradient-to-r from-cyan-300 via-sky-400 to-cyan-400 pulse-glow active:scale-95 transition-transform"
      }
    >
      {copied ? copiedLabel : label}
    </button>
  );
}

export default function App() {
  const [showScript, setShowScript] = useState(false);
  const [keyVisible, setKeyVisible] = useState(false);

  const scriptStats = useMemo(() => {
    const lines = LUA_SCRIPT.split("\n").length;
    const kb = (new Blob([LUA_SCRIPT]).size / 1024).toFixed(1);
    return { lines, kb };
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* backgrounds */}
      <div className="aurora" />
      <div className="orb w-64 h-64 bg-cyan-500/40 -top-16 -left-20" />
      <div className="orb w-72 h-72 bg-sky-600/30 top-1/3 -right-24" style={{ animationDelay: "-3s" }} />
      <div className="orb w-56 h-56 bg-teal-500/30 bottom-10 left-1/4" style={{ animationDelay: "-6s" }} />

      {/* ── header ── */}
      <header className="safe-top sticky top-0 z-50 px-4 pb-2">
        <div className="glass rounded-2xl px-4 py-3 flex items-center justify-between max-w-3xl mx-auto">
          <div className="flex items-center gap-2">
            <span className="text-2xl drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]">⚡</span>
            <div className="leading-tight">
              <p className="font-black text-sm tracking-widest text-cyan-100">SHOWEY HUB</p>
              <p className="text-[10px] text-cyan-400/80 font-semibold">v3.1 FULL · STABLE</p>
            </div>
          </div>
          <a
            href={DISCORD_LINK}
            target="_blank"
            rel="noreferrer"
            className="text-xs font-bold px-3.5 py-2 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 active:scale-95 transition-transform"
          >
            💬 Discord
          </a>
        </div>
      </header>

      <main className="px-4 max-w-3xl mx-auto">
        {/* ── hero ── */}
        <section className="pt-8 pb-6 text-center fade-up">
          <div className="flex flex-wrap justify-center gap-2 mb-5">
            <span className="text-[11px] font-bold px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-300">
              📱 Delta iOS Ready
            </span>
            <span className="text-[11px] font-bold px-3 py-1.5 rounded-full bg-sky-500/10 border border-sky-400/30 text-sky-300">
              🌊 Rayfield · Ocean
            </span>
            <span className="text-[11px] font-bold px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-400/30 text-emerald-300">
              <span className="blink-dot inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 align-middle" />
              ONLINE
            </span>
          </div>

          <h1 className="glow-title text-5xl sm:text-6xl font-black tracking-tight leading-none">
            SHOWEY HUB
          </h1>
          <p className="mt-2 text-cyan-200/90 font-extrabold text-lg tracking-[0.35em]">⚡ v3.1 FULL ⚡</p>
          <p className="mt-4 text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            El hub definitivo para <span className="text-cyan-300 font-semibold">Delta Executor iOS</span>.
            Fly corregido para móvil, anti-crash, aimbot assist, ESP y 12 pestañas cargadas de funciones.
            <span className="text-slate-300"> Optimizado 100% para iPhone.</span> 🇲🇽 🇬🇹
          </p>

          {/* stats */}
          <div className="grid grid-cols-3 gap-2.5 mt-7">
            {[
              { v: "12", l: "PESTAÑAS" },
              { v: "80+", l: "FUNCIONES" },
              { v: `${scriptStats.lines}`, l: "LÍNEAS LUA" },
            ].map((s) => (
              <div key={s.l} className="glass rounded-2xl py-3.5">
                <p className="text-xl font-black text-cyan-300">{s.v}</p>
                <p className="text-[9px] font-bold tracking-[0.2em] text-slate-500 mt-0.5">{s.l}</p>
              </div>
            ))}
          </div>

          {/* main CTA */}
          <div className="mt-6 space-y-3">
            <CopyButton
              text={LUA_SCRIPT}
              label="📋 COPIAR SCRIPT COMPLETO"
              copiedLabel="✅ ¡SCRIPT COPIADO! PÉGALO EN DELTA"
            />
            <button
              onClick={() => setShowScript((s) => !s)}
              className="w-full rounded-2xl px-6 py-3.5 font-bold text-sm text-cyan-200 glass glass-hover"
            >
              {showScript ? "🙈 Ocultar código" : "👀 Ver código del script"}
            </button>
          </div>
        </section>

        {/* ── script viewer ── */}
        {showScript && (
          <section className="pb-8 fade-up">
            <div className="glass rounded-3xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-cyan-400/10 bg-slate-950/60">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-400/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400/80" />
                  <span className="ml-2 text-[11px] font-mono text-slate-500">
                    showey_hub_v3.1.lua · {scriptStats.kb} KB
                  </span>
                </div>
                <CopyButton
                  text={LUA_SCRIPT}
                  label="📋 Copiar"
                  copiedLabel="✅ Listo"
                  className="text-[11px] font-bold px-3 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/30 text-cyan-200 active:scale-95 transition-transform"
                />
              </div>
              <pre className="code-scroll text-[11px] leading-relaxed font-mono text-cyan-100/80 p-4 overflow-auto max-h-[55vh] whitespace-pre">
                {LUA_SCRIPT}
              </pre>
            </div>
          </section>
        )}

        {/* ── key card ── */}
        <section className="pb-8 fade-up">
          <div className="glass rounded-3xl p-5 border-cyan-400/25">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-400/25 to-sky-600/25 border border-cyan-400/30 flex items-center justify-center text-xl">
                🔐
              </div>
              <div>
                <h2 className="font-black text-sm tracking-wide text-cyan-100">SISTEMA DE KEY</h2>
                <p className="text-[11px] text-slate-500">Verificación de acceso · SaveKey activado</p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-slate-950/70 border border-cyan-400/15 rounded-2xl px-4 py-3.5">
              <code className="flex-1 font-mono text-sm text-cyan-300 truncate select-all">
                {keyVisible ? SCRIPT_KEY : "•".repeat(SCRIPT_KEY.length)}
              </code>
              <button
                onClick={() => setKeyVisible((v) => !v)}
                className="text-lg px-1 active:scale-90 transition-transform"
                aria-label="mostrar key"
              >
                {keyVisible ? "🙈" : "👁️"}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 mt-3">
              <CopyButton
                text={SCRIPT_KEY}
                label="🔑 Copiar Key"
                copiedLabel="✅ Copiada"
                className="rounded-xl px-4 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-cyan-300 to-sky-400 active:scale-95 transition-transform"
              />
              <a
                href={DISCORD_LINK}
                target="_blank"
                rel="noreferrer"
                className="rounded-xl px-4 py-3 text-sm font-bold text-center text-indigo-200 bg-indigo-500/15 border border-indigo-400/30 active:scale-95 transition-transform"
              >
                💬 Obtener Key
              </a>
            </div>
          </div>
        </section>

        {/* ── how to (Delta iOS) ── */}
        <section className="pb-8 fade-up">
          <h2 className="text-center font-black text-lg text-cyan-100 tracking-wide mb-1">
            📱 Cómo usarlo en <span className="glow-title">Delta iOS</span>
          </h2>
          <p className="text-center text-xs text-slate-500 mb-5">4 pasos y listo — sin PC, directo desde tu iPhone</p>

          <div className="space-y-3">
            {STEPS.map((s) => (
              <div key={s.n} className="glass glass-hover rounded-2xl p-4 flex items-start gap-4">
                <div className="shrink-0 w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-sky-700/20 border border-cyan-400/25 flex items-center justify-center text-2xl">
                  {s.icon}
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-black text-cyan-500/80 tracking-[0.3em]">PASO {s.n}</p>
                  <h3 className="font-bold text-sm text-slate-100 mt-0.5">{s.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── features grid ── */}
        <section className="pb-8 fade-up">
          <h2 className="text-center font-black text-lg text-cyan-100 tracking-wide mb-1">
            🧩 12 Pestañas · Todo Incluido
          </h2>
          <p className="text-center text-xs text-slate-500 mb-5">Cada módulo con anti-crash y protección silenciosa</p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {TABS.map((t) => (
              <div key={t.name} className="glass glass-hover rounded-2xl p-4">
                <div className="text-2xl mb-2 drop-shadow-[0_0_12px_rgba(34,211,238,0.35)]">{t.icon}</div>
                <h3 className="font-black text-[11px] tracking-widest text-cyan-200">{t.name}</h3>
                <p className="text-[10.5px] text-slate-500 mt-1 leading-snug">{t.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── highlights ── */}
        <section className="pb-8 fade-up">
          <div className="glass rounded-3xl p-5">
            <h2 className="font-black text-sm tracking-wide text-cyan-100 mb-4">✨ Destacado en v3.1</h2>
            <ul className="space-y-3">
              {[
                ["🚀", "Fly corregido para móvil", "Botones táctiles ▲ SUBIR / ▼ BAJAR flotantes en pantalla, con gradientes y respuesta al toque."],
                ["🛡️", "Anti-detección silenciosa", "Hook de __namecall + bloqueo de remotes de anticheat, kick y ban."],
                ["📱", "iOS Boost integrado", "FPS Unlocker a 120, modo ahorro de batería y limpieza de memoria."],
                ["💥", "Anti-Crash total", "Cada función envuelta en pcall y conexiones administradas para no tirar el juego."],
              ].map(([icon, title, desc]) => (
                <li key={title} className="flex items-start gap-3">
                  <span className="text-xl shrink-0">{icon}</span>
                  <div>
                    <p className="text-sm font-bold text-slate-100">{title}</p>
                    <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* ── final CTA ── */}
        <section className="pb-6 fade-up">
          <div className="glass rounded-3xl p-6 text-center border-cyan-400/25">
            <p className="text-3xl mb-2">⚡</p>
            <h2 className="font-black text-xl text-cyan-100">¿Listo para dominar?</h2>
            <p className="text-xs text-slate-500 mt-1 mb-5">Copia el script y ejecútalo en Delta ahora mismo.</p>
            <CopyButton
              text={LUA_SCRIPT}
              label="📋 COPIAR SCRIPT"
              copiedLabel="✅ ¡COPIADO! ÁBRELO EN DELTA"
            />
          </div>
        </section>
      </main>

      {/* ── footer ── */}
      <footer className="safe-bottom px-4 pt-2 text-center">
        <p className="text-[11px] text-slate-600 font-semibold">
          ⚡ SHOWEY HUB v3.1 · 🇲🇽 MX · 🇬🇹 GT ·{" "}
          <a href={DISCORD_LINK} target="_blank" rel="noreferrer" className="text-cyan-500/80">
            discord.gg/showey
          </a>
        </p>
        <p className="text-[10px] text-slate-700 mt-1">Solo con fines educativos. Úsalo bajo tu propio riesgo.</p>
      </footer>
    </div>
  );
}
